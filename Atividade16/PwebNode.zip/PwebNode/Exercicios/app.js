/*var express = require('express');

var app=express(); // executando o express
*/
/*app.set('view engine', 'ejs');

app.get('/', function(req,res){
res.send("<html><body>Site da Fatec Sorocaba</body></html>");
});

app.get('/historia', function(req,res){
res.render("secao/historia");
});
app.get('/cursos', function(req,res){
res.render("secao/cursos");
});
app.get('/professores', function(req,res){
res.render("secao/professores");
});
app.listen(3000, function(){
console.log("servidor com express foi carregado");
});*/
/*
app.get('/historia',function(req,res){
  res.send("<html><body>historia da Fatec Sorocaba</body></html>")
});
app.get('/cursos',function(req,res){
  res.send("<html><body>cursos da Fatec Sorocaba</body></html>")
});
app.get('/professores',function(req,res){
  res.send("<html><body>professores da Fatec Sorocaba</body></html>")
});/*
app.listen(3000,function(){
  console.log("servidor com express carregado.")
});*/
//var express = require('express');
/*
var app = require('./app/config/server'); // carregando o módulo do servidor



app.get('/', function(req,res){
res.render("home/index");
});



app.get('/formulario_adicionar_usuario', function(req,res){
res.render("admin/adicionar_usuario");
});



app.get('/informacao/historia', function(req,res){
res.render("informacao/historia");
});



app.get('/informacao/cursos', function(req,res){
res.render("informacao/cursos")
});



app.get('/informacao/professores', function(req,res){
res.render("informacao/professores");
});



app.listen(3000, function(){
console.log("servidor iniciado");
});*/
var app = require('./app/config/server');
/*var rotaHome = require('./app/routes/home');
rotaHome(app);
var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);
var rotaHistoria = require('./app/routes/historia'); // só está definindo
rotaHistoria(app); // está executando
var rotaCursos = require('./app/routes/cursos'); // só está definindo
rotaCursos(app); // está executando
var rotaProfessores = require('./app/routes/professores'); // só está definindo
rotaProfessores(app); // está executando
/* poderia executar assim também*/
/*
var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario')(app);
*/

app.listen(3000, function(){
  console.log("servidor iniciado");
});
